This work is based on the following software and libraries:
python, pytorch, numpy, pandas, openCV

Reference:
1.	LeCun, Y., Bengio, Y., & Hinton, G. (2015). Deep learning. nature, 521(7553), 436-444.
2.	https://en.wikipedia.org/wiki/Convolutional_neural_network
3.	https://s3-us-west-1.amazonaws.com/udacity-aind/dog-project/dogImages.zip
4.	https://docs.opencv.org/trunk/d7/d8b/tutorial_py_face_detection.html
5.	Simonyan, K., & Zisserman, A. (2014). Very deep convolutional networks for large-scale image recognition. arXiv preprint arXiv:1409.1556.
6.	http://www.image-net.org/
7.	https://neurohive.io/en/popular-networks/vgg16/
